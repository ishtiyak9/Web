<?php
$pagetitle="student data";
include "include/header_loginpage.php"; ?>


			<div class="main">

				<div class="content">

                    <div class="text-center">
                        <hr class="team_hr team_hr_left hr_gray"/><span class="span_blog txt_darkgrey txt_orange">Login Page</span>
                        <hr class="team_hr team_hr_right hr_gray" />
                    </div>  <!-- text-center -->
 
				    <br><br><br>
				    <center>
					<div class="loginpage">
				    <a class="admin" href="Login.php">Login as Admin</a>
					<!-- </div> -->

					<a class="admin" href="http://localhost:8082/FINALPROJECT2/teacher/login_teacher.php">Login as Teacher</a>
				    
				   <!--  <div> -->
				    <a class="admin" href="http://localhost:8082/FINALPROJECT2/user/login_user.php">Login as User</a>
				    </div>

					</center>
				    
                    

				</div> <!-- content -->


<?php include "include/footer.php"; ?>	