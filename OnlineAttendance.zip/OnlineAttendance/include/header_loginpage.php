
<!-- <!DOCTYPE html> -->
<!-- <html lang="en"> -->
<html >

	<head>
		<title><?php echo $pagetitle; ?></title>
		<link rel="stylesheet" href="http://localhost:8082/FINALPROJECT2/css/C.css" type="text/css">
	</head>


	<body>

		<div id="page">

			<div class="header">

				<img src="http://localhost:8082/FINALPROJECT2/image/vu.jpg" alt="logo" width="350" height="104" align="left">

			</div> <!-- header -->
