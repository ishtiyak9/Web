<?php 
	for ($i=0; $i <2 ; $i++) { 
		echo rand(1,100).'<br>';
	}
	

?>