<div class="footer">
					<div class="footer_txt" >
	                                <span>  
	                        <div class="footer_bottom_content">
	                            <br>
	                            Copyright&copy; Web Based Student Management System
	                            <br><br>
	                       
	                             Supervisor: <a href="https://www.facebook.com/merajalicse" target="new">Meraj Ali</a><br>
	                             
	                        </div></span>
	     
	                </div> <!-- footer_txt --> 
				</div>  <!-- footer -->

		 	<!-- </div> main -->
			
		</div> <!-- page -->

	</body>

</html>